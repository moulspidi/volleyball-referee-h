package com.tonkar.volleyballreferee.ui.interfaces;

import com.tonkar.volleyballreferee.engine.game.IGame;

public interface GameServiceHandler {

    void setGameService(IGame game);

}
