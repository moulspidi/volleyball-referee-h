package com.tonkar.volleyballreferee.ui.interfaces;

import com.tonkar.volleyballreferee.engine.service.StoredGamesService;

public interface StoredGamesServiceHandler {

    void setStoredGamesService(StoredGamesService storedGamesService);

}
