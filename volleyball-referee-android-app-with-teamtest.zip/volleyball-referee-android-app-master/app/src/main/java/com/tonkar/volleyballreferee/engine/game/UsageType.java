package com.tonkar.volleyballreferee.engine.game;

public enum UsageType {
    NORMAL,
    POINTS_SCOREBOARD
}
