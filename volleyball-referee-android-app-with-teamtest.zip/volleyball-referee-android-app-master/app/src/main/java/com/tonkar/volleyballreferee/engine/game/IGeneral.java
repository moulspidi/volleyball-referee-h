package com.tonkar.volleyballreferee.engine.game;

public interface IGeneral extends IBaseGeneral {

    void startMatch();

    void resetCurrentSet();
}
