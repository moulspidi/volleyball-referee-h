package com.tonkar.volleyballreferee.engine.game;

public interface IBaseTime {

    long getRemainingTime();

    long getRemainingTime(int setIndex);
}
