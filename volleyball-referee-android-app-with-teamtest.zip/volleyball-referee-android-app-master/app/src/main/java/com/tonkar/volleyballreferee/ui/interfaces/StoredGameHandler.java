package com.tonkar.volleyballreferee.ui.interfaces;

import com.tonkar.volleyballreferee.engine.service.IStoredGame;

public interface StoredGameHandler {

    void setStoredGame(IStoredGame storedGame);

}
