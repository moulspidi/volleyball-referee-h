package com.tonkar.volleyballreferee.engine.game;

public enum GameStatus {
    SCHEDULED,
    LIVE,
    COMPLETED
}
