package com.tonkar.volleyballreferee.ui.teamtest;

public class TeamTestItem {
    public final String id;
    public final String name;
    public final String stadium;

    public TeamTestItem(String id, String name, String stadium) {
        this.id = id;
        this.name = name;
        this.stadium = stadium;
    }
}
