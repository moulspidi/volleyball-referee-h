package com.tonkar.volleyballreferee.ui.interfaces;

import com.tonkar.volleyballreferee.engine.team.IBaseTeam;

public interface BaseTeamServiceHandler {

    void setTeamService(IBaseTeam teamService);

}
