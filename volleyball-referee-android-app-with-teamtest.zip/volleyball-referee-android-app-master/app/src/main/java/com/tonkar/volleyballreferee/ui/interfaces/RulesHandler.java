package com.tonkar.volleyballreferee.ui.interfaces;

import com.tonkar.volleyballreferee.engine.rules.Rules;

public interface RulesHandler {

    void setRules(Rules rules);

}
