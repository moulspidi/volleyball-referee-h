package com.tonkar.volleyballreferee.engine.game;

public enum GameType {
    INDOOR,
    BEACH,
    INDOOR_4X4,
    SNOW
}