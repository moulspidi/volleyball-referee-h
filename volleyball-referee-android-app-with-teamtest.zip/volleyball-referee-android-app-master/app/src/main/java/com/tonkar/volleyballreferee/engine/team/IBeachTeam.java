package com.tonkar.volleyballreferee.engine.team;

public interface IBeachTeam extends ITeam {

    void swapPlayers(TeamType teamType);

}
