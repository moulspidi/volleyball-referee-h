package com.tonkar.volleyballreferee.engine.teamtest;

import android.content.Context;
import android.content.SharedPreferences;

import androidx.preference.PreferenceManager;

public class TeamTestStore {
    private static final String KEY_ID = "pref_test_team_id";
    private static final String KEY_NAME = "pref_test_team_name";

    public static void save(Context context, String id, String name) {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
        sp.edit().putString(KEY_ID, id).putString(KEY_NAME, name).apply();
    }

    public static String getId(Context context) {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
        return sp.getString(KEY_ID, null);
    }

    public static String getName(Context context) {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
        return sp.getString(KEY_NAME, null);
    }
}
