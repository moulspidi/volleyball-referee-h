package com.tonkar.volleyballreferee.ui.teamtest;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.tonkar.volleyballreferee.R;

public class TeamTestAdapter extends ListAdapter<TeamTestItem, TeamTestAdapter.VH> {

    public interface OnClick {
        void onTeamClick(TeamTestItem item);
    }

    private final OnClick onClick;

    public TeamTestAdapter(OnClick onClick) {
        super(DIFF);
        this.onClick = onClick;
    }

    @NonNull @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_team_test, parent, false);
        return new VH(v, onClick);
    }

    @Override
    public void onBindViewHolder(@NonNull VH holder, int position) {
        holder.bind(getItem(position));
    }

    static class VH extends RecyclerView.ViewHolder {
        private final TextView title;
        private final TextView subtitle;
        private TeamTestItem item;

        VH(View itemView, OnClick onClick) {
            super(itemView);
            title = itemView.findViewById(R.id.title);
            subtitle = itemView.findViewById(R.id.subtitle);
            itemView.setOnClickListener(v -> {
                if (item != null) onClick.onTeamClick(item);
            });
        }

        void bind(TeamTestItem i) {
            item = i;
            title.setText(i.name);
            subtitle.setText(i.stadium == null ? "" : i.stadium);
        }
    }

    public static final DiffUtil.ItemCallback<TeamTestItem> DIFF = new DiffUtil.ItemCallback<TeamTestItem>() {
        @Override public boolean areItemsTheSame(@NonNull TeamTestItem a, @NonNull TeamTestItem b) { return a.id.equals(b.id); }
        @Override public boolean areContentsTheSame(@NonNull TeamTestItem a, @NonNull TeamTestItem b) { 
            boolean stadiumEq = (a.stadium == null && b.stadium == null) || (a.stadium != null && a.stadium.equals(b.stadium));
            return a.name.equals(b.name) && stadiumEq;
        }
    };
}
