package com.tonkar.volleyballreferee.ui.teamtest;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.tonkar.volleyballreferee.R;
import com.tonkar.volleyballreferee.engine.teamtest.TeamTestStore;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;

public class TeamTestPickerActivity extends AppCompatActivity {

    private final OkHttpClient client = new OkHttpClient();
    private final Gson gson = new Gson();
    private TeamTestAdapter adapter;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_team_test_picker);
        setTitle(R.string.team_test_title);

        RecyclerView recycler = findViewById(R.id.recycler);
        recycler.setLayoutManager(new LinearLayoutManager(this));
        recycler.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));

        adapter = new TeamTestAdapter(item -> {
            TeamTestStore.save(this, item.id, item.name);
            Toast.makeText(this, getString(R.string.team_test_saved, item.name), Toast.LENGTH_SHORT).show();
            finish();
        });
        recycler.setAdapter(adapter);

        EditText input = findViewById(R.id.search_input);
        ImageButton go = findViewById(R.id.search_go);

        Runnable trigger = () -> search(input.getText().toString().trim());
        go.setOnClickListener(v -> trigger.run());
        input.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH) { trigger.run(); return true; }
            return false;
        });
    }

    private void search(String q) {
        if (TextUtils.isEmpty(q)) {
            Toast.makeText(this, R.string.team_test_empty, Toast.LENGTH_SHORT).show();
            return;
        }
        Executors.newSingleThreadExecutor().execute(() -> {
            String url = "https://www.thesportsdb.com/api/v1/json/3/searchteams.php?t=" + q;
            Request req = new Request.Builder().url(url).get().build();
            try (Response res = client.newCall(req).execute()) {
                if (!res.isSuccessful()) {
                    runOnUiThread(() -> Toast.makeText(this, "HTTP " + res.code(), Toast.LENGTH_SHORT).show());
                    return;
                }
                ResponseBody body = res.body();
                if (body == null) return;
                String json = body.string();
                JsonObject root = gson.fromJson(json, JsonObject.class);
                JsonArray arr = root.has("teams") && root.get("teams").isJsonArray() ? root.getAsJsonArray("teams") : null;
                List<TeamTestItem> items = new ArrayList<>();
                if (arr != null) {
                    for (JsonElement el : arr) {
                        JsonObject t = el.getAsJsonObject();
                        String id = t.has("idTeam") && !t.get("idTeam").isJsonNull() ? t.get("idTeam").getAsString() : "";
                        String name = t.has("strTeam") && !t.get("strTeam").isJsonNull() ? t.get("strTeam").getAsString() : "";
                        String stadium = t.has("strStadium") && !t.get("strStadium").isJsonNull() ? t.get("strStadium").getAsString() : null;
                        if (!TextUtils.isEmpty(id) && !TextUtils.isEmpty(name)) {
                            items.add(new TeamTestItem(id, name, stadium));
                        }
                    }
                }
                runOnUiThread(() -> adapter.submitList(items));
            } catch (IOException e) {
                runOnUiThread(() -> Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show());
            }
        });
    }
}
